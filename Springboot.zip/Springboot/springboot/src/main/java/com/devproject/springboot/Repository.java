package com.devproject.springboot;

import org.springframework.data.repository.CrudRepository;

public interface Repository extends CrudRepository<Curso,Long>{

    

}